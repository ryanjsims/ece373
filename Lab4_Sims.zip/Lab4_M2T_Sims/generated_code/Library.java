
public class Library {
	private ArrayList<Book> books;

	public ArrayList<Book> getBooks() {
		return this.books;
	}

	public void setBooks(ArrayList<Book> books) {
		this.books = books;
	}

	public Book findBook( String title ) {
		// TODO should be implemented
	}
}
