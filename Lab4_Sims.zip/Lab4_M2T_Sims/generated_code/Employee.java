
public abstract class Employee extends Person {
	private int iD;

	public int getID() {
		return this.iD;
	}

	public void setID(int iD) {
		this.iD = iD;
	}

	public void borrowBook( Book b1 ) {
		// TODO should be implemented
	}

	public void returnBook( Book b1 ) {
		// TODO should be implemented
	}
}
