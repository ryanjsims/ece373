
public class Professor extends Employee {



}
