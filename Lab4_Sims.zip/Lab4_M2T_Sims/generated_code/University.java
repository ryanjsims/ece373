
public class University {



}
