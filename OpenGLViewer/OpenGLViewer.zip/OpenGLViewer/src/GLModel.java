import java.nio.FloatBuffer;

public class GLModel {
    private FloatBuffer positions, normals;
    //private int vao,
}
