package org.hrs.system;

// Test driver by Lahiru Ariyananda

public class Driver2 
{
	public static void main(String[] args)
	{
		HRGUI hrGui = new HRGUI("HR GUI");    
	}
}
